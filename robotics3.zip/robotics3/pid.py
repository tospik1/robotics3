class PIDController:
    def __init__(self, target_pos):
        self.target_pos = 0
        self.Kp = 2200  
        self.Ki = 4400  
        self.Kd = 650  
        self.bias = 0
	self.time = 1.0/60.0
	self.I_eq = 0
	self.error_prev = 0       
	return

    def reset(self):
        return

#TODO: Complete your PID control within this function. At the moment, it holds
#      only the bias. Your final solution must use the error between the 
#      target_pos and the ball position, plus the PID gains. You cannot
#      use the bias in your final answer. 
    def get_fan_rpm(self, vertical_ball_position):
	
	error = self.target_pos - vertical_ball_position
	diff_error = error - self.error_prev
	
	P_eq = error
        self.I_eq = self.I_eq + error * self.time
	D_eq = diff_error / self.time

	self.bias = 1750 + ((self.Kp * P_eq) + (self.Ki * self.I_eq) + (self.Kd * D_eq)) # 1750 RPM is around the value of RPM that couteracts the force of gravity
	self.error_prev = error
        output = self.bias
	
	
	if (output > 10000):
		output = 8000
	
        return output


